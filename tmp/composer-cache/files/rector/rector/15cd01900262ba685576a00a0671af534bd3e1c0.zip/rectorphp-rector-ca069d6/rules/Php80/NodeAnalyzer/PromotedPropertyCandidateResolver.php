<?php

declare (strict_types=1);
namespace Rector\Php80\NodeAnalyzer;

use PhpParser\Node;
use PhpParser\Node\Expr\ArrayDimFetch;
use PhpParser\Node\Expr\Assign;
use PhpParser\Node\Expr\PropertyFetch;
use PhpParser\Node\Expr\Variable;
use PhpParser\Node\Param;
use PhpParser\Node\Stmt\Class_;
use PhpParser\Node\Stmt\ClassMethod;
use PhpParser\Node\Stmt\Expression;
use PhpParser\Node\Stmt\Property;
use Rector\BetterPhpDocParser\PhpDocInfo\PhpDocInfo;
use Rector\BetterPhpDocParser\PhpDocInfo\PhpDocInfoFactory;
use Rector\Enum\ClassName;
use Rector\NodeAnalyzer\PropertyFetchAnalyzer;
use Rector\NodeNameResolver\NodeNameResolver;
use Rector\Php80\ValueObject\PropertyPromotionCandidate;
use Rector\PhpParser\Comparing\NodeComparator;
use Rector\PhpParser\Node\BetterNodeFinder;
final class PromotedPropertyCandidateResolver
{
    /**
     * @readonly
     */
    private NodeNameResolver $nodeNameResolver;
    /**
     * @readonly
     */
    private BetterNodeFinder $betterNodeFinder;
    /**
     * @readonly
     */
    private NodeComparator $nodeComparator;
    /**
     * @readonly
     */
    private PropertyFetchAnalyzer $propertyFetchAnalyzer;
    /**
     * @readonly
     */
    private PhpDocInfoFactory $phpDocInfoFactory;
    /**
     * @readonly
     */
    private \Rector\Php80\NodeAnalyzer\PhpAttributeAnalyzer $phpAttributeAnalyzer;
    public function __construct(NodeNameResolver $nodeNameResolver, BetterNodeFinder $betterNodeFinder, NodeComparator $nodeComparator, PropertyFetchAnalyzer $propertyFetchAnalyzer, PhpDocInfoFactory $phpDocInfoFactory, \Rector\Php80\NodeAnalyzer\PhpAttributeAnalyzer $phpAttributeAnalyzer)
    {
        $this->nodeNameResolver = $nodeNameResolver;
        $this->betterNodeFinder = $betterNodeFinder;
        $this->nodeComparator = $nodeComparator;
        $this->propertyFetchAnalyzer = $propertyFetchAnalyzer;
        $this->phpDocInfoFactory = $phpDocInfoFactory;
        $this->phpAttributeAnalyzer = $phpAttributeAnalyzer;
    }
    /**
     * @return PropertyPromotionCandidate[]
     */
    public function resolveFromClass(Class_ $class, ClassMethod $constructClassMethod, bool $allowModelBasedClasses): array
    {
        if (!$allowModelBasedClasses && $this->hasModelTypeCheck($class, ClassName::DOCTRINE_ENTITY)) {
            return [];
        }
        $propertyPromotionCandidates = [];
        foreach ($class->stmts as $classStmtPosition => $classStmt) {
            if (!$classStmt instanceof Property) {
                continue;
            }
            if (count($classStmt->props) !== 1) {
                continue;
            }
            $propertyPromotionCandidate = $this->matchPropertyPromotionCandidate($classStmt, $constructClassMethod, $classStmtPosition);
            if (!$propertyPromotionCandidate instanceof PropertyPromotionCandidate) {
                continue;
            }
            if (!$allowModelBasedClasses && $this->hasModelTypeCheck($classStmt, ClassName::JMS_TYPE)) {
                continue;
            }
            $propertyPromotionCandidates[] = $propertyPromotionCandidate;
        }
        return $propertyPromotionCandidates;
    }
    /**
     * @param \PhpParser\Node\Stmt\Class_|\PhpParser\Node\Stmt\Property $node
     */
    private function hasModelTypeCheck($node, string $modelType): bool
    {
        $phpDocInfo = $this->phpDocInfoFactory->createFromNode($node);
        if ($phpDocInfo instanceof PhpDocInfo && $phpDocInfo->hasByAnnotationClass($modelType)) {
            return \true;
        }
        return $this->phpAttributeAnalyzer->hasPhpAttribute($node, $modelType);
    }
    private function matchPropertyPromotionCandidate(Property $property, ClassMethod $constructClassMethod, int $propertyStmtPosition): ?PropertyPromotionCandidate
    {
        if ($property->flags === 0) {
            return null;
        }
        $onlyProperty = $property->props[0];
        $propertyName = $this->nodeNameResolver->getName($onlyProperty);
        $firstParamAsVariable = $this->resolveFirstParamUses($constructClassMethod);
        // match property name to assign in constructor
        foreach ((array) $constructClassMethod->stmts as $assignStmtPosition => $stmt) {
            if (!$stmt instanceof Expression) {
                continue;
            }
            if (!$stmt->expr instanceof Assign) {
                continue;
            }
            $assign = $stmt->expr;
            // promoted property must use non-static property only
            if (!$assign->var instanceof PropertyFetch) {
                continue;
            }
            if (!$this->propertyFetchAnalyzer->isLocalPropertyFetchName($assign->var, $propertyName)) {
                continue;
            }
            // 1. is param
            $assignedExpr = $assign->expr;
            if (!$assignedExpr instanceof Variable) {
                continue;
            }
            $matchedParam = $this->matchClassMethodParamByAssignedVariable($constructClassMethod, $assignedExpr);
            if (!$matchedParam instanceof Param) {
                continue;
            }
            if ($this->shouldSkipParam($matchedParam, $assignedExpr, $firstParamAsVariable)) {
                continue;
            }
            if ($this->isParamReadAfterPropertyMutation($constructClassMethod, $assignStmtPosition, $propertyName, $matchedParam)) {
                continue;
            }
            return new PropertyPromotionCandidate($property, $matchedParam, $propertyStmtPosition, $assignStmtPosition);
        }
        return null;
    }
    /**
     * @return array<string, int>
     */
    private function resolveFirstParamUses(ClassMethod $classMethod): array
    {
        $paramByFirstUsage = [];
        foreach ($classMethod->params as $param) {
            $paramName = $this->nodeNameResolver->getName($param);
            $firstParamVariable = $this->betterNodeFinder->findFirst((array) $classMethod->stmts, function (Node $node) use ($paramName): bool {
                if (!$node instanceof Variable) {
                    return \false;
                }
                return $this->nodeNameResolver->isName($node, $paramName);
            });
            if (!$firstParamVariable instanceof Node) {
                continue;
            }
            $paramByFirstUsage[$paramName] = $firstParamVariable->getStartTokenPos();
        }
        return $paramByFirstUsage;
    }
    private function matchClassMethodParamByAssignedVariable(ClassMethod $classMethod, Variable $variable): ?Param
    {
        foreach ($classMethod->params as $param) {
            if (!$this->nodeComparator->areNodesEqual($variable, $param->var)) {
                continue;
            }
            return $param;
        }
        return null;
    }
    /**
     * @param array<string, int> $firstParamAsVariable
     */
    private function isParamUsedBeforeAssign(Variable $variable, array $firstParamAsVariable): bool
    {
        $variableName = $this->nodeNameResolver->getName($variable);
        $firstVariablePosition = $firstParamAsVariable[$variableName] ?? null;
        if ($firstVariablePosition === null) {
            return \false;
        }
        return $firstVariablePosition < $variable->getStartTokenPos();
    }
    /**
     * The rule rewrites later $param reads to $this->property. That is only safe while $this->property still
     * equals the param. Once the property is mutated in the constructor, a following $param read would diverge,
     * so the promotion must be skipped.
     */
    private function isParamReadAfterPropertyMutation(ClassMethod $constructClassMethod, int $assignStmtPosition, string $propertyName, Param $matchedParam): bool
    {
        $followingStmts = array_slice((array) $constructClassMethod->stmts, $assignStmtPosition + 1);
        if ($followingStmts === []) {
            return \false;
        }
        $firstMutationTokenPos = null;
        foreach ($this->betterNodeFinder->findInstanceOf($followingStmts, Assign::class) as $assign) {
            $assignVar = $assign->var;
            while ($assignVar instanceof ArrayDimFetch) {
                $assignVar = $assignVar->var;
            }
            if (!$this->propertyFetchAnalyzer->isLocalPropertyFetchName($assignVar, $propertyName)) {
                continue;
            }
            $tokenPos = $assign->var->getStartTokenPos();
            if ($firstMutationTokenPos === null || $tokenPos < $firstMutationTokenPos) {
                $firstMutationTokenPos = $tokenPos;
            }
        }
        if ($firstMutationTokenPos === null) {
            return \false;
        }
        $paramName = $this->nodeNameResolver->getName($matchedParam);
        return $this->betterNodeFinder->findFirst($followingStmts, function (Node $node) use ($paramName, $firstMutationTokenPos): bool {
            if (!$node instanceof Variable) {
                return \false;
            }
            if (!$this->nodeNameResolver->isName($node, $paramName)) {
                return \false;
            }
            return $node->getStartTokenPos() > $firstMutationTokenPos;
        }) instanceof Node;
    }
    /**
     * @param int[] $firstParamAsVariable
     */
    private function shouldSkipParam(Param $matchedParam, Variable $assignedVariable, array $firstParamAsVariable): bool
    {
        // already promoted
        if ($matchedParam->isPromoted()) {
            return \true;
        }
        return $this->isParamUsedBeforeAssign($assignedVariable, $firstParamAsVariable);
    }
}
