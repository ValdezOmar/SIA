<?php

return [

    'label' => 'Lädt...',

];
