<?php

return [

    'label' => 'Tabs',

];
