<?php

return [

    'label' => 'Inapakia...',

];
