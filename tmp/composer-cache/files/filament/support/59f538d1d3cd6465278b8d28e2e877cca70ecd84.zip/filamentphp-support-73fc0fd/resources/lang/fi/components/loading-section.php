<?php

return [

    'label' => 'Ladataan...',

];
