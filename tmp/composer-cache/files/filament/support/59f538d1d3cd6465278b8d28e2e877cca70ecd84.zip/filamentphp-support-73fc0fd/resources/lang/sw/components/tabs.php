<?php

return [

    'label' => 'Vichupo',

];
