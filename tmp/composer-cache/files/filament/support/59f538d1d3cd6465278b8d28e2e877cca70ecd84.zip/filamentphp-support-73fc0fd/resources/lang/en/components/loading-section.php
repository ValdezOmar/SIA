<?php

return [

    'label' => 'Loading...',

];
