<?php

return [
    'label' => 'Esporta',
];
