<?php

return [
    'label' => 'تصدير',
];
