<?php

return [
    'label' => 'Xuất',
];
