<?php

return [
    'label' => 'Изтегли',
];
