<?php

return [
    'label' => 'Ekspor',
];
