<?php

return [
    'label' => 'エクスポート',
];
