<?php

return [
    'label' => 'Exporteren',
];
