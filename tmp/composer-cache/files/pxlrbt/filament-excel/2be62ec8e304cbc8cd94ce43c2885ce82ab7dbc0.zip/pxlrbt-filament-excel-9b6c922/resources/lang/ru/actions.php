<?php

return [
    'label' => 'Экспорт',
];
