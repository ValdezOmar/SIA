<?php

return [
    'label' => 'Exportieren',
];
