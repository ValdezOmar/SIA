<?php

return [
    'label' => 'Eksportuj',
];
