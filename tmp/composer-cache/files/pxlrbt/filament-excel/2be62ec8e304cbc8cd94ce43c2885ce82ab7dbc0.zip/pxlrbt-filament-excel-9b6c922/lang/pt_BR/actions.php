<?php

return [
    'label' => 'Exportar',
];
